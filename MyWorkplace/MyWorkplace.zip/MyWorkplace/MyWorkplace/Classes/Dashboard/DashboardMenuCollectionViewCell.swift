//
//  RoomCollectionViewCell.swift
//  MyWorkplace
//
//  Created by Gayatri Nagarkar on 17/10/17.
//  Copyright © 2017 Gayatri Nagarkar. All rights reserved.
//

import UIKit

class DashboardMenuCollectionViewCell: UICollectionViewCell {
 
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var iconImageView: UIImageView!
}
